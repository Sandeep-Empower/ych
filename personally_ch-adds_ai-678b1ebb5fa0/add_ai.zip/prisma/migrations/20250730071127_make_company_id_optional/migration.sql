-- AlterTable
ALTER TABLE "Company" ADD COLUMN     "status" BOOLEAN NOT NULL DEFAULT true;
